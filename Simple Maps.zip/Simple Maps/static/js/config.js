// API key
const API_KEY = "pk.eyJ1IjoiYWxhYmlub3dpY3oiLCJhIjoiY2w0NGZpZjllMGJ0dDNrcDhpaDdseWM5cSJ9.o5OcGx91-OmM3iV90VOrLA";